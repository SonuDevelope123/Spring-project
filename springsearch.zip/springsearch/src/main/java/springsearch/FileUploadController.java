package springsearch;

import java.io.File;
import java.io.FileOutputStream;

import javax.servlet.http.HttpSession;

import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.multipart.commons.CommonsMultipartFile;

@Controller
public class FileUploadController {
	
	
	@RequestMapping("/fileform")
	public String showUploadForm() {
		return "fileUpload";
	}
	@RequestMapping(value="/upload", method = RequestMethod.POST)
	public String upload(@RequestParam("file") CommonsMultipartFile file, HttpSession s,Model moel) {
		System.out.println("File Upload handler");
		System.out.println(file.getSize());
		System.out.println(file.getContentType());
		System.out.println(file.getName());
		String path;
		byte[] b=file.getBytes();
		 path=s.getServletContext().getRealPath("/")+"WEB-INF"+File.separator+"resources"+File.separator+"image"+File.separator+file.getOriginalFilename();
		try {
		FileOutputStream fos=new FileOutputStream(path);
		fos.write(b); 
		fos.close();
		moel.addAttribute("msg","upload succesfully");
		moel.addAttribute("filename",path);
		System.out.println("Done");
		}catch(Exception e) {
			
		}
		
		System.out.println(path);
		return "filesucces";
	}

}
