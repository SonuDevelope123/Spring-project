package springsearch;

import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;

@Controller
public class LoginController {
	
	
	@RequestMapping(path="/login",method=RequestMethod.POST)
	public String Login(@RequestParam("username") String username, @RequestParam("password") String pass) {
		System.out.println(username+"  "+pass);
		if(username.equals("root")&&pass.equals("root")) {
			return "redirect:/home";
			
		}else {
		return "redirect:/";
		}
	}
	@RequestMapping(value="/validateUserName", method=RequestMethod.POST)
	@ResponseBody
	public String validateUserName(@RequestParam("username") String username, @RequestParam("password") String pass)
	{
		System.out.println("------------------------");
		if(username.equalsIgnoreCase("root"))
		{
			return "success result";
		}else
		{
			return "success result   @";
		}
	}

}
