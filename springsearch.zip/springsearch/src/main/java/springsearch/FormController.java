package springsearch;

import javax.servlet.http.HttpServletRequest;
import javax.websocket.server.PathParam;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;

import springsearch.dao.StudentDao;
import springsearch.formbean.Product;
import springsearch.formbean.Student;
import springsearch.service.UserService;

@Controller
public class FormController {
	
	@Autowired
	private StudentDao studentdao;
	@Autowired
	private UserService service;
	@RequestMapping("/complex")
	public String showForm() {
		return "redirect:/home";
	}
	
	
	@RequestMapping(path="/handlerform" ,method=RequestMethod.POST)
	public String formHandler(@ModelAttribute("student") Student student,BindingResult result) {
		
		
		if(result.hasErrors()) { 
			return "complex_form";
		}
		System.out.println(student);
		
		int i=this.service.createUser(student);
		System.out.println(student);
		 return "redirect://";
	}
	@RequestMapping("/")
	public String home() {
		
		return "home";
	}
	
	@RequestMapping(path="/add",method=RequestMethod.POST)
	public String addproduct(@ModelAttribute("product") Product product,HttpServletRequest request) {
		System.out.println(product);
		studentdao.createProduct(product);
		return "redirect:/home";
		
	}
	
	// Geting data
	@RequestMapping("/edit")
	public String edit(@PathParam("id") int id,Model model) {
		Product product=studentdao.getProduct(id); 
		model.addAttribute("data",product);
		System.out.println(product);
		return "edit";
		
	}
	@RequestMapping("/delete")
	public String delete(@PathParam("id") int id) {
        studentdao.productDelete(id);
		return "redirect:/home";
		
	}
	
	

}
