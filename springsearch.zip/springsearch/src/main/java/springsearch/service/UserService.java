package springsearch.service;




import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import springsearch.dao.StudentDao;
import springsearch.formbean.Student;

@Service
public class UserService {
	@Autowired
	private StudentDao studentdao;
	public int createUser(Student student) {
		int id= this.studentdao.insert(student);
		return id;
		}

}
